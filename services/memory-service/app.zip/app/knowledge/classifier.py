from app.knowledge.knowledge_types import KnowledgeDecision
from app.knowledge.fact_extractor import extract_fact
from app.knowledge.contradiction_detector import detect_contradiction
from app.understanding.memory_parser import parse_memory


def get_memory_object(item):
    if hasattr(item, "content"):
        return item
    if hasattr(item, "__getitem__"):
        return item[0]
    return item


def is_merge_equivalent(new_parsed, existing_mem, distance=None) -> bool:
    if detect_contradiction(new_parsed, existing_mem):
        return False

    if not hasattr(existing_mem, "content"):
        return False

    existing_parsed = parse_memory(existing_mem.content)
    new_fact = extract_fact(new_parsed)
    existing_fact = extract_fact(existing_parsed)

    if new_fact and existing_fact:
        if (
            new_fact.entity.strip().lower()
            == existing_fact.entity.strip().lower()
            and new_fact.attribute.strip().lower()
            == existing_fact.attribute.strip().lower()
        ):
            return (
                new_fact.value.strip().lower()
                == existing_fact.value.strip().lower()
            )

    new_entities = {e.text.lower() for e in new_parsed.entities}
    existing_entities = {e.text.lower() for e in existing_parsed.entities}

    shared_entities = new_entities.intersection(existing_entities)
    if shared_entities:
        if distance is None or distance < 0.25:
            return True

    return False


def classify_knowledge(
    parsed_memory,
    candidates,
):
    if not candidates:
        return KnowledgeDecision.NEW

    # 1. Scan candidates for strict fact UPDATE (same entity + same attribute + different value)
    if parsed_memory is not None:
        new_fact = extract_fact(parsed_memory)
        if new_fact is not None:
            norm_entity = new_fact.entity.strip().lower()
            norm_attribute = new_fact.attribute.strip().lower()
            norm_value = new_fact.value.strip().lower()

            for item in candidates:
                cand_mem = get_memory_object(item)
                if hasattr(cand_mem, "content"):
                    existing_parsed = parse_memory(cand_mem.content)
                    existing_fact = extract_fact(existing_parsed)
                    if existing_fact is not None:
                        ex_entity = existing_fact.entity.strip().lower()
                        ex_attribute = existing_fact.attribute.strip().lower()
                        ex_value = existing_fact.value.strip().lower()
                        if (
                            ex_entity == norm_entity
                            and ex_attribute == norm_attribute
                            and ex_value != norm_value
                        ):
                            return KnowledgeDecision.UPDATE

    # 2. Check for MERGE using explicit merge equivalence check
    if parsed_memory is not None:
        for item in candidates:
            cand_mem = get_memory_object(item)
            dist = (
                item[1]
                if hasattr(item, "__getitem__") and len(item) > 1
                else None
            )
            if is_merge_equivalent(parsed_memory, cand_mem, distance=dist):
                if (
                    hasattr(cand_mem, "content")
                    and parsed_memory.content.strip().lower()
                    == cand_mem.content.strip().lower()
                ):
                    return KnowledgeDecision.REINFORCEMENT
                return KnowledgeDecision.MERGE

    # 3. Distance classification against top candidate
    best_cand = candidates[0]
    best_mem = get_memory_object(best_cand)
    distance = (
        best_cand[1]
        if hasattr(best_cand, "__getitem__") and len(best_cand) > 1
        else None
    )

    if distance is None:
        return KnowledgeDecision.NEW

    if distance < 0.10:
        return KnowledgeDecision.REINFORCEMENT

    if distance < 0.35:
        return KnowledgeDecision.RELATED

    return KnowledgeDecision.NEW