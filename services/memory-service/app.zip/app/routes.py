from fastapi import APIRouter

from . import service
from .context_service import build_context
from .schemas import (
    MemoryCreate,
    MemoryUpdate,
    MemoryResponse,
)

router = APIRouter()


@router.get(
    "/memory",
    response_model=list[MemoryResponse],
)
def get_memories(
    category: str | None = None,
    min_importance: float | None = None,
    keyword: str | None = None,
):
    return service.get_memories(
        category=category,
        min_importance=min_importance,
        keyword=keyword,
    )


@router.post(
    "/memory",
    response_model=MemoryResponse,
)
def create_memory(memory: MemoryCreate):
    return service.create_memory(
        content=memory.content,
        category=memory.category,
    )

# TODO:
# Run contradiction detection
# before storing memory.

@router.put(
    "/memory/{memory_id}",
    response_model=MemoryResponse,
)
def update_memory(
    memory_id: int,
    memory: MemoryUpdate,
):
    return service.update_memory(
        memory_id=memory_id,
        content=memory.content,
    )


@router.delete("/memory/{memory_id}")
def delete_memory(memory_id: int):
    return service.delete_memory(memory_id)


@router.get(
    "/context",
    response_model=list[MemoryResponse],
)
def get_context(
    query: str | None = None,
    top_k: int = 5,
):
    return build_context(
        query=query,
        top_k=top_k,
    )